To use it, put the following in your Emacs configuration file:

  (load-theme 'afternoon t)

Requirements: Emacs 24.
