This package runs CMake and sets variables for IDE-like functionality
provided by other packages such as:
On the fly syntax checks with flycheck
auto-completion using auto-complete-clang or company-clang
Jump to definition and refactoring with rtags
These other packages must be installed for the functionality to work
