Running `achievements-list-achievements' will show a list of all
unlocked achievements.  To earn some achievements, and to check
automatically for earned achievements, you must enable
`achievements-mode`.
